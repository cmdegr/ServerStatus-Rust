pub mod server_status {
    tonic::include_proto!("server_status");
}
